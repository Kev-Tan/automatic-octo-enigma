// Global.js
window.Global = {
    life: 3,
    score: 0,
    move: 1,
    // Add any other global variables or functions here
};
