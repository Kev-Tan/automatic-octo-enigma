"use strict";
cc._RF.push(module, '04f92J2OFBN4relp/zuiTNT', 'Transition Script 2');
// scripts/Transition Script 2.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // Add any properties here if needed
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        // Initialization code if needed
        // For example, attaching event listeners if necessary
    },
    start: function start() {
        // Example function to demonstrate scene transition with delay
        this.transitionToLevel2AfterDelay();
    },


    // Method to transition to Level1 after a 2-second delay
    transitionToLevel2AfterDelay: function transitionToLevel2AfterDelay() {
        console.log("Waiting 2 seconds before transitioning to Level2...");

        // Wait for 2 seconds (2000 milliseconds) before executing the scene transition
        setTimeout(function () {
            // Transition to Level1 scene
            cc.director.loadScene('Level2', function (err) {
                if (err) {
                    console.error('Failed to load Level2:', err);
                } else {
                    console.log('Level2 loaded successfully.');
                }
            });
        }, 3000); // 2000 milliseconds = 2 seconds
    },


    // Update method if needed
    update: function update(dt) {
        // Your update logic here
    }
});

cc._RF.pop();