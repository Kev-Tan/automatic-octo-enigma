"use strict";
cc._RF.push(module, '1152a1MdDNPCa9UZtQshQI8', 'Global Data Script');
// scripts/Global Data Script.js

"use strict";

// Global.js
window.Global = {
    life: 3,
    score: 0,
    move: 1
    // Add any other global variables or functions here
};

cc._RF.pop();