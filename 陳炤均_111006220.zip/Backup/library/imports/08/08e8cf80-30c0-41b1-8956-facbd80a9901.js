"use strict";
cc._RF.push(module, '08e8c+AMMBBsYlW+svYCpkB', 'Level1 Script');
// scripts/Level1 Script.js

"use strict";

// Level1Script.js
cc.Class({
    extends: cc.Component,

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        // Enable the physics manager when this scene loads
        cc.director.getPhysicsManager().enabled = true;
        console.log(window.Global.life);
    }
}

// Other methods and logic for the Level1 scene can be added here
);

cc._RF.pop();