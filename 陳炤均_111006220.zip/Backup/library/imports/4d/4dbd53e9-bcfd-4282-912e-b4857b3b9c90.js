"use strict";
cc._RF.push(module, '4dbd5PpvP1CgpEutIV7O5yQ', 'Collider Interface');
// scripts/Collider Interface.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // Define any properties if needed
    },

    onLoad: function onLoad() {
        // Enable collision manager
        cc.director.getCollisionManager().enabled = true;
        // cc.director.getCollisionManager().enabledDebugDraw = true;
        // cc.director.getCollisionManager().enabledDrawBoundingBox = true;

        // Register collision callback
        this.node.on('onCollisionEnter', this.onCollisionEnter, this);
    }
});

cc._RF.pop();