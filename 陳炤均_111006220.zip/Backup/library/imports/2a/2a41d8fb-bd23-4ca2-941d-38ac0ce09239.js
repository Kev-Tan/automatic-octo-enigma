"use strict";
cc._RF.push(module, '2a41dj7vSNMopQdOKwM4JI5', 'Shooter Script');
// scripts/Shooter Script.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // The fire projectile prefab
        firePrefab: {
            default: null,
            type: cc.Prefab
        },
        // The interval between shots
        shootInterval: 2, // seconds
        // The speed of the fire projectile
        projectileSpeed: 500,
        // Optional: sound effects
        deathSound: {
            default: null,
            type: cc.AudioClip
        },
        kickSound: {
            default: null,
            type: cc.AudioClip
        },
        jumpImpulse: {
            default: 300, // Adjust this value to set how high Mario should jump
            type: cc.Float
        }
    },

    onLoad: function onLoad() {
        // Schedule the shooting function to run every shootInterval seconds
        this.schedule(this.shootFire, this.shootInterval);

        // Enable collision manager and debug draw
        cc.director.getCollisionManager().enabled = true;
        cc.director.getCollisionManager().enabledDebugDraw = true;
        cc.director.getCollisionManager().enabledDrawBoundingBox = true;

        // Add a BoxCollider component to the enemy
        var collider = this.node.addComponent(cc.BoxCollider);
        collider.size = this.node.getContentSize();
        collider.group = 'Enemy'; // Set to a specific group if needed
    },
    shootFire: function shootFire() {
        // Access the Animation component
        var animation = this.node.getComponent(cc.Animation);

        // Play the shooting animation
        if (animation) {
            animation.play('turtle animation'); // Ensure this matches the actual animation clip name
        }

        // Create the fire projectile instance from the prefab
        var fireProjectile = cc.instantiate(this.firePrefab);

        // Set the initial position of the projectile to the enemy's position
        fireProjectile.setPosition(this.node.position);

        // Add the projectile to the scene
        this.node.parent.addChild(fireProjectile);

        // Get the RigidBody component of the projectile
        var rigidBody = fireProjectile.getComponent(cc.RigidBody);

        if (rigidBody) {
            // Set the initial velocity of the projectile
            var direction = cc.v2(-1, 0); // Fire to the left
            var velocity = direction.mul(this.projectileSpeed);
            rigidBody.linearVelocity = velocity;
        }
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        // Check if the collision is with the player or other specific objects
        if (other.node.group === 'Actor') {
            window.Global.score += 10;
            console.log(window.Global.score);
            var player = other.node;
            var playerRb = player.getComponent(cc.RigidBody);

            if (playerRb) {
                var verticalSpeed = playerRb.linearVelocity.y;
                var playerBox = player.getBoundingBoxToWorld();
                var enemyBox = this.node.getBoundingBoxToWorld();

                if (verticalSpeed < 0 && playerBox.yMax > enemyBox.yMax && playerBox.yMin < enemyBox.yMax) {
                    // Handle case where player jumps on the enemy
                    console.log('Player jumped on enemy!');
                    this.handleEnemyDeath(playerRb); // Pass the player’s Rigidbody to handleEnemyDeath
                } else {
                    // Handle case where player touches the enemy from the side or bottom
                    console.log('Player touched the enemy from the side or bottom!');
                    window.Global.score = 0;
                    this.handlePlayerDeath();
                }
            }
        }
    },
    handleEnemyDeath: function handleEnemyDeath(playerRb) {
        var _this = this;

        // Play the kick sound
        if (this.kickSound) {
            cc.audioEngine.playEffect(this.kickSound, false);
        }

        // Access the Animation component
        var animation = this.node.getComponent(cc.Animation);

        if (animation) {
            // Play the turtle die animation
            animation.play('turtle die animation'); // Ensure this matches the actual animation clip name
            // Optionally, handle animation completion before destroying the node

            this.scheduleOnce(function () {
                // Destroy the enemy node after the animation
                _this.node.destroy();
            }, 0.4); // Adjust delay based on animation duration
        } else {
            // If no animation component, destroy immediately
            this.node.destroy();
        }

        // Apply an upward impulse to Mario
        if (playerRb) {
            var currentVelocity = playerRb.linearVelocity;
            var jumpVelocity = cc.v2(currentVelocity.x, this.jumpImpulse);
            playerRb.linearVelocity = jumpVelocity;
        }

        // Update the score
        window.Global.score += 5;
    },
    handlePlayerDeath: function handlePlayerDeath() {
        // Stop any currently playing music
        cc.audioEngine.stopMusic();

        // Play the death sound
        if (this.deathSound) {
            cc.audioEngine.playEffect(this.deathSound, false);
        }

        // Decrease life only once
        if (window.Global) {
            console.log("Current life before decrease:", window.Global.life);
            window.Global.life -= 1;
            console.log("Current life after decrease:", window.Global.life);
        } else {
            console.warn("Global object not found.");
        }

        // Get the name of the current scene
        var currentSceneName = cc.director.getScene().name;

        // Determine the scene to transition to based on the current scene
        var transitionScene = '';
        if (currentSceneName === 'Level1') {
            transitionScene = 'Transition Scene 1';
        } else if (currentSceneName === 'Level2') {
            transitionScene = 'Transition Scene 2';
        }

        // Schedule scene transition based on remaining life
        if (window.Global.life > 0) {
            this.scheduleOnce(function () {
                cc.director.loadScene(transitionScene);
            }, 0.05); // Adjust the delay to 0.05 seconds for the death sound to play
        } else {
            this.scheduleOnce(function () {
                cc.director.loadScene('Game Over');
                window.Global.life = 3;
            }, 0.05); // Adjust the delay to 0.05 seconds for the death sound to play
        }
    },
    start: function start() {},
    update: function update(dt) {}
});

cc._RF.pop();